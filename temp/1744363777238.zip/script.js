javascript
document.getElementById('ctaButton').addEventListener('click', function() {
    alert('Thanks for your interest! Stay tuned for updates.');
});