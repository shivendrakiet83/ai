// script.js
// Add any interactive functionality here