// script.js
// Add JavaScript for form validation and confirmation messages