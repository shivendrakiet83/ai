javascript
// script.js

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Perform login validation here
    alert('Login button clicked!');
});